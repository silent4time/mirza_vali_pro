<?php
/**
 * mirza_vali Pro — License client
 * Domain-locked subscription. Expiry stops SALES only (bot stays online).
 * Grace: if license server unreachable, use last good cache for up to 96h.
 */
if (!defined('MV_LICENSE_CLIENT')) {
    define('MV_LICENSE_CLIENT', true);
}

function mv_license_cache_path(): string
{
    $dir = defined('BOT_ROOT') ? BOT_ROOT : __DIR__;
    $storage = $dir . '/storage';
    if (!is_dir($storage)) {
        @mkdir($storage, 0750, true);
    }
    return $storage . '/license_cache.json';
}

function mv_license_config(): array
{
    global $LICENSE_ENABLED, $LICENSE_KEY, $LICENSE_API_URL, $domainhosts;
    $enabled = true;
    if (isset($LICENSE_ENABLED)) {
        $enabled = (bool) $LICENSE_ENABLED;
    }
    $key = isset($LICENSE_KEY) ? trim((string) $LICENSE_KEY) : '';
    $api = isset($LICENSE_API_URL) ? trim((string) $LICENSE_API_URL) : '';
    if ($api === '') {
        $api = 'https://license.example.com/api/verify.php';
    }
    $domain = isset($domainhosts) ? trim((string) $domainhosts) : '';
    $domain = preg_replace('#^https?://#i', '', $domain);
    $domain = strtolower(rtrim($domain, '/'));
    return [
        'enabled' => $enabled,
        'key' => $key,
        'api' => $api,
        'domain' => $domain,
        'grace_hours' => 96,
        'check_ttl' => 3600, // re-check online at most hourly
    ];
}

function mv_license_read_cache(): ?array
{
    $path = mv_license_cache_path();
    if (!is_file($path)) {
        return null;
    }
    $j = json_decode((string) @file_get_contents($path), true);
    return is_array($j) ? $j : null;
}

function mv_license_write_cache(array $data): void
{
    $data['cached_at'] = time();
    @file_put_contents(mv_license_cache_path(), json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
}

function mv_license_http_verify(string $api, string $key, string $domain): ?array
{
    $payload = json_encode(['license_key' => $key, 'domain' => $domain], JSON_UNESCAPED_UNICODE);
    if (function_exists('curl_init')) {
        $ch = curl_init($api);
        curl_setopt_array($ch, [
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Accept: application/json'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_CONNECTTIMEOUT => 3,
            CURLOPT_TIMEOUT => 6,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $body = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($body === false || $body === '') {
            return null;
        }
        $j = json_decode($body, true);
        if (!is_array($j)) {
            return null;
        }
        $j['_http'] = $code;
        return $j;
    }
    $ctx = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => "Content-Type: application/json\r\n",
            'content' => $payload,
            'timeout' => 6,
            'ignore_errors' => true,
        ],
    ]);
    $body = @file_get_contents($api, false, $ctx);
    if ($body === false) {
        return null;
    }
    $j = json_decode($body, true);
    return is_array($j) ? $j : null;
}

/**
 * @return array{
 *   sales_ok:bool,ok:bool,source:string,code:string,message:string,
 *   expired?:bool,warn?:bool,days_left?:int,expires_at?:string,grace?:bool
 * }
 */
function mv_license_status(bool $force = false): array
{
    static $memo = null;
    if ($memo !== null && !$force) {
        return $memo;
    }

    $cfg = mv_license_config();
    if (!$cfg['enabled']) {
        return $memo = [
            'sales_ok' => true,
            'ok' => true,
            'source' => 'disabled',
            'code' => 'disabled',
            'message' => 'license check disabled',
        ];
    }
    if ($cfg['key'] === '' || $cfg['domain'] === '' || $cfg['domain'] === 'PENDING') {
        return $memo = [
            'sales_ok' => false,
            'ok' => false,
            'source' => 'config',
            'code' => 'not_configured',
            'message' => 'لایسنس تنظیم نشده است. کلید لایسنس و دامنه را در config.php وارد کنید.',
        ];
    }

    $cache = mv_license_read_cache();
    $now = time();
    if (!$force && is_array($cache) && !empty($cache['checked_at']) && ($now - (int) $cache['checked_at']) < (int) $cfg['check_ttl']) {
        $cache['source'] = 'cache_ttl';
        return $memo = $cache;
    }

    $remote = mv_license_http_verify($cfg['api'], $cfg['key'], $cfg['domain']);
    if (is_array($remote)) {
        $sales_ok = !empty($remote['sales_ok']);
        // hard failures from server
        if (empty($remote['ok']) && in_array(($remote['code'] ?? ''), ['not_found', 'revoked', 'domain_mismatch', 'bad_request'], true)) {
            $sales_ok = false;
        }
        $out = [
            'sales_ok' => $sales_ok,
            'ok' => !empty($remote['ok']),
            'source' => 'remote',
            'code' => (string) ($remote['code'] ?? 'unknown'),
            'message' => (string) ($remote['message'] ?? ''),
            'expired' => !empty($remote['expired']),
            'warn' => !empty($remote['warn']),
            'days_left' => isset($remote['days_left']) ? (int) $remote['days_left'] : null,
            'expires_at' => (string) ($remote['expires_at'] ?? ''),
            'grace' => false,
            'checked_at' => $now,
            'last_ok_at' => $sales_ok || !empty($remote['ok']) ? $now : (int) ($cache['last_ok_at'] ?? 0),
        ];
        if (!empty($remote['ok']) || $sales_ok) {
            $out['last_ok_at'] = $now;
        }
        // keep last_ok_at from previous good cache if this response is expired but structured
        if (!$out['last_ok_at'] && is_array($cache) && !empty($cache['last_ok_at'])) {
            $out['last_ok_at'] = (int) $cache['last_ok_at'];
        }
        mv_license_write_cache($out);
        mv_license_maybe_notify_admin($out);
        return $memo = $out;
    }

    // Server unreachable → grace from last good cache
    $graceHours = (int) ($cache['grace_hours'] ?? $cfg['grace_hours']);
    if (isset($remote['grace_hours'])) {
        $graceHours = (int) $remote['grace_hours'];
    }
    $lastOk = is_array($cache) ? (int) ($cache['last_ok_at'] ?? $cache['checked_at'] ?? 0) : 0;
    $inGrace = $lastOk > 0 && ($now - $lastOk) <= ($graceHours * 3600);

    if ($inGrace && is_array($cache)) {
        $out = $cache;
        $out['source'] = 'grace';
        $out['grace'] = true;
        $out['code'] = 'grace';
        $out['message'] = 'سرور لایسنس در دسترس نیست؛ حالت مهلت (grace) فعال است.';
        $out['checked_at'] = $now;
        // sales_ok stays as last known
        mv_license_write_cache($out);
        return $memo = $out;
    }

    $out = [
        'sales_ok' => false,
        'ok' => false,
        'source' => 'offline',
        'code' => 'server_unreachable',
        'message' => 'سرور لایسنس در دسترس نیست و مهلت ۹۶ ساعته تمام شده است. فروش متوقف شد.',
        'grace' => false,
        'checked_at' => $now,
        'last_ok_at' => $lastOk,
    ];
    mv_license_write_cache($out);
    return $memo = $out;
}

function mv_license_sales_allowed(): bool
{
    try {
        $st = mv_license_status();
        return !empty($st['sales_ok']);
    } catch (Throwable $e) {
        error_log('mv_license_sales_allowed: ' . $e->getMessage());
        return true; // fail open for bot availability; sales policy enforced when check works
    }
}

function mv_license_user_message(): string
{
    $st = mv_license_status();
    if (!empty($st['sales_ok'])) {
        return '';
    }
    if (($st['code'] ?? '') === 'expired' || !empty($st['expired'])) {
        return "⛔️ فروش موقتاً متوقف است.\nلایسنس این ربات منقضی شده است. لطفاً با پشتیبانی فروشنده ربات تماس بگیرید.";
    }
    if (($st['code'] ?? '') === 'not_configured') {
        return "⛔️ فروش فعال نیست.\nلایسنس ربات هنوز تنظیم نشده است.";
    }
    if (($st['code'] ?? '') === 'domain_mismatch') {
        return "⛔️ فروش متوقف است.\nدامنه ربات با لایسنس مطابقت ندارد.";
    }
    if (($st['code'] ?? '') === 'revoked') {
        return "⛔️ فروش متوقف است.\nلایسنس باطل شده است.";
    }
    return "⛔️ فروش موقتاً در دسترس نیست.\n" . (string) ($st['message'] ?? 'خطای لایسنس');
}

function mv_license_is_sales_action($text, $datain, $userStep = ''): bool
{
    global $textbotlang;
    $sell = $textbotlang['textbot']['sell'] ?? '';
    $extend = $textbotlang['textbot']['extend'] ?? '';
    if ($sell !== '' && $text === $sell) {
        return true;
    }
    if ($extend !== '' && $text === $extend) {
        return true;
    }
    $dataTriggers = ['buy', 'buyback', 'buybacktow', 'productcheckdata'];
    if (is_string($datain) && in_array($datain, $dataTriggers, true)) {
        return true;
    }
    if (is_string($datain) && (strpos($datain, 'product_') === 0 || strpos($datain, 'buy') === 0 || strpos($datain, 'location_') === 0)) {
        return true;
    }
    if (in_array($text, ['/buy', 'buy'], true)) {
        return true;
    }
    $steps = ['statusnamecustom', 'selectlocation', 'selectproduct', 'selectpayment'];
    if (is_string($userStep) && in_array($userStep, $steps, true)) {
        return true;
    }
    return false;
}

/**
 * If sales blocked and this is a sales action → notify user and return true (caller should return).
 */
function mv_license_block_sales_if_needed($from_id, $text, $datain, $userStep = ''): bool
{
    try {
        if (mv_license_sales_allowed()) {
            return false;
        }
        if (!mv_license_is_sales_action($text, $datain, $userStep)) {
            return false;
        }
        $msg = mv_license_user_message();
        if ($msg !== '' && $from_id) {
            if (function_exists('sendmessage')) {
                sendmessage($from_id, $msg, null, 'HTML');
            }
        }
        return true;
    } catch (Throwable $e) {
        error_log('mv_license_block_sales_if_needed: ' . $e->getMessage());
        return false;
    }
}

function mv_license_maybe_notify_admin(array $st): void
{
    global $adminnumber, $BALE_ADMIN_ID;
    $flagPath = (defined('BOT_ROOT') ? BOT_ROOT : __DIR__) . '/storage/license_notify_flags.json';
    $flags = [];
    if (is_file($flagPath)) {
        $flags = json_decode((string) @file_get_contents($flagPath), true) ?: [];
    }
    $day = gmdate('Y-m-d');
    $msgs = [];
    if (!empty($st['expired']) || ($st['code'] ?? '') === 'expired') {
        $k = 'expired_' . $day;
        if (empty($flags[$k])) {
            $msgs[] = "⚠️ لایسنس ربات منقضی شد.\nفروش متوقف شده است. ربات همچنان آنلاین است.\nانقضا: " . ($st['expires_at'] ?? '-');
            $flags[$k] = time();
        }
    } elseif (!empty($st['warn'])) {
        $k = 'warn_' . $day;
        if (empty($flags[$k])) {
            $left = $st['days_left'] ?? '?';
            $msgs[] = "⏰ هشدار لایسنس\nحدود {$left} روز تا انقضا باقی مانده است.\nتاریخ انقضا: " . ($st['expires_at'] ?? '-');
            $flags[$k] = time();
        }
    }
    if (!$msgs) {
        return;
    }
    @file_put_contents($flagPath, json_encode($flags, JSON_UNESCAPED_UNICODE));
    if (!function_exists('sendmessage')) {
        return;
    }
    foreach ($msgs as $m) {
        if (!empty($adminnumber)) {
            @sendmessage($adminnumber, $m, null, 'HTML');
        }
        if (!empty($BALE_ADMIN_ID)) {
            // Bale admin id may need platform context; best-effort
            @sendmessage($BALE_ADMIN_ID, $m, null, 'HTML');
        }
    }
}
