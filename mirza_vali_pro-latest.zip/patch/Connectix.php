<?php
/**
 * Connectix seller API integration for mirza_vali
 * Docs (Swagger): https://seller-api.connectix.vip/external/v1
 * Auth: Authorization: Bearer <API_TOKEN>
 *
 * Panel fields:
 *   type           = connectix
 *   url_panel      = https://seller-api.connectix.vip/external/v1
 *   password_panel = API token
 *   username_panel = (unused / null)
 *   inboundid      = (unused)
 *
 * Product fields after sync:
 *   note           = plan UUID (plan_id)
 *   category       = کانکتیکس
 *   Location       = name_panel
 */

if (!function_exists('connectix_request')) {

function connectix_default_base()
{
    return 'https://seller-api.connectix.vip/external/v1';
}

function connectix_get_panel($namepanel)
{
    $panel = select('marzban_panel', '*', 'name_panel', $namepanel, 'select');
    if (!is_array($panel) || ($panel['type'] ?? '') !== 'connectix') {
        return null;
    }
    return $panel;
}

/**
 * HTTP helper — Bearer token in password_panel
 */
function connectix_request($method, $endpoint, $panel, $body = null, $multipart = false)
{
    $base = rtrim((string) ($panel['url_panel'] ?? ''), '/');
    if ($base === '' || $base === 'null') {
        $base = connectix_default_base();
    }
    // ensure /external/v1 path if user only put host
    if (stripos($base, '/external') === false) {
        $base = rtrim($base, '/') . '/external/v1';
    }
    $url = $base . (str_starts_with($endpoint, '/') ? $endpoint : '/' . $endpoint);
    $token = trim((string) ($panel['password_panel'] ?? ''));
    if ($token === '' || $token === 'null') {
        return ['http_code' => 0, 'error' => 'missing API token', 'body' => null];
    }

    $ch = curl_init($url);
    $headers = [
        'Accept: application/json',
        'Authorization: Bearer ' . $token,
    ];
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, strtoupper($method));

    if ($body !== null) {
        if ($multipart) {
            // multipart/form-data via array (curl builds boundary)
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        } else {
            $headers[] = 'Content-Type: application/json';
            curl_setopt($ch, CURLOPT_POSTFIELDS, is_string($body) ? $body : json_encode($body, JSON_UNESCAPED_UNICODE));
        }
    }
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $raw = curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $cerr = curl_error($ch);
    curl_close($ch);

    $decoded = null;
    if (is_string($raw) && $raw !== '') {
        $decoded = json_decode($raw, true);
    }
    $out = [
        'http_code' => $code,
        'body' => $decoded,
        'raw' => is_string($raw) ? mb_substr($raw, 0, 2000) : '',
    ];
    if ($cerr) {
        $out['error'] = $cerr;
    }
    if (is_array($decoded)) {
        if (isset($decoded['message'])) {
            $out['message'] = $decoded['message'];
        }
        foreach ($decoded as $k => $v) {
            if (!isset($out[$k])) {
                $out[$k] = $v;
            }
        }
    }
    return $out;
}

function connectix_http_ok($result)
{
    $c = (int) ($result['http_code'] ?? 0);
    return $c >= 200 && $c < 300 && empty($result['error']);
}

/** GET /clients/get-enabled-plans */
function connectix_get_plans($namepanel)
{
    $panel = is_array($namepanel) ? $namepanel : connectix_get_panel($namepanel);
    if (!$panel) {
        return ['http_code' => 0, 'error' => 'panel not found', 'plans' => []];
    }
    $res = connectix_request('GET', '/clients/get-enabled-plans', $panel);
    $plans = [];
    if (isset($res['body']['plans']) && is_array($res['body']['plans'])) {
        $plans = $res['body']['plans'];
    } elseif (isset($res['plans']) && is_array($res['plans'])) {
        $plans = $res['plans'];
    }
    $res['plans'] = $plans;
    return $res;
}

function connectix_gen_password($len = 8)
{
    $len = max(5, min(8, (int) $len));
    $chars = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789';
    $out = '';
    for ($i = 0; $i < $len; $i++) {
        $out .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return $out;
}

/**
 * POST /clients/store  (multipart/form-data)
 * Required: password, plan_id
 */
function connectix_create_client($namepanel, $plan_id, $password, $extra = [])
{
    $panel = is_array($namepanel) ? $namepanel : connectix_get_panel($namepanel);
    if (!$panel) {
        return ['http_code' => 0, 'error' => 'panel not found', 'success' => false];
    }
    $form = [
        'password' => (string) $password,
        'plan_id' => (string) $plan_id,
    ];
    foreach (['telegram_id', 'name', 'phone', 'email', 'chat_id'] as $k) {
        if (isset($extra[$k]) && $extra[$k] !== '' && $extra[$k] !== null) {
            $form[$k] = (string) $extra[$k];
        }
    }
    if (isset($extra['enable_plan_after_first_login'])) {
        $form['enable_plan_after_first_login'] = $extra['enable_plan_after_first_login'] ? '1' : '0';
    }
    if (isset($extra['is_child_protection_enabled'])) {
        $form['is_child_protection_enabled'] = $extra['is_child_protection_enabled'] ? '1' : '0';
    }

    $res = connectix_request('POST', '/clients/store', $panel, $form, true);
    $res['success'] = connectix_http_ok($res);
    return $res;
}

/** Parse text_to_copy for username / password */
function connectix_parse_credentials($text_to_copy)
{
    $text = str_replace('`', '', (string) $text_to_copy);
    $user = '';
    $pass = '';
    if (preg_match('/username\s*:\s*([^\s\n]+)/iu', $text, $m)) {
        $user = trim($m[1]);
    }
    if (preg_match('/password\s*:\s*([^\s\n]+)/iu', $text, $m)) {
        $pass = trim($m[1]);
    }
    return ['username' => $user, 'password' => $pass, 'raw' => $text_to_copy];
}

/**
 * Sync enabled plans → product rows under category کانکتیکس
 * Returns ['added'=>n,'updated'=>n,'total'=>n,'error'=>...]
 */
function connectix_sync_products($namepanel)
{
    global $pdo;
    $panel = is_array($namepanel) ? $namepanel : connectix_get_panel($namepanel);
    if (!$panel) {
        return ['added' => 0, 'updated' => 0, 'total' => 0, 'error' => 'panel not found'];
    }
    $name = $panel['name_panel'];
    $res = connectix_get_plans($panel);
    if (!connectix_http_ok($res)) {
        return [
            'added' => 0,
            'updated' => 0,
            'total' => 0,
            'error' => $res['message'] ?? $res['error'] ?? ('HTTP ' . ($res['http_code'] ?? 0)),
        ];
    }
    $plans = $res['plans'] ?? [];
    $added = 0;
    $updated = 0;
    $category = 'کانکتیکس';

    foreach ($plans as $plan) {
        if (!is_array($plan) || empty($plan['id'])) {
            continue;
        }
        $planId = (string) $plan['id'];
        $title = (string) ($plan['title'] ?? $plan['full_period_text'] ?? 'Connectix Plan');
        $price = (string) ($plan['sell_price'] ?? '0');
        $days = (string) intval($plan['full_period_days'] ?? $plan['period'] ?? 0);
        $traffic = $plan['traffic_amount'] ?? '';
        // volume in GB if numeric, else 0
        $vol = 0;
        if (is_numeric($traffic)) {
            $vol = (string) intval($traffic);
        } elseif (is_string($traffic) && preg_match('/(\d+)/', $traffic, $vm)) {
            $vol = $vm[1];
        }
        $devices = intval($plan['count_of_devices'] ?? 1);
        $code = substr(md5('cx|' . $name . '|' . $planId), 0, 10);

        // find existing by note=plan_id + Location
        $existing = null;
        try {
            $st = $pdo->prepare("SELECT id, code_product FROM product WHERE note = :note AND Location = :loc LIMIT 1");
            $st->execute([':note' => $planId, ':loc' => $name]);
            $existing = $st->fetch(PDO::FETCH_ASSOC);
        } catch (Throwable $e) {
        }

        if ($existing) {
            try {
                $st = $pdo->prepare("UPDATE product SET name_product=:n, price_product=:p, Volume_constraint=:v, Service_time=:t, category=:c, max_users=:m WHERE id=:id");
                $st->execute([
                    ':n' => $title,
                    ':p' => $price,
                    ':v' => $vol,
                    ':t' => $days,
                    ':c' => $category,
                    ':m' => (string) $devices,
                    ':id' => $existing['id'],
                ]);
                $updated++;
            } catch (Throwable $e) {
                error_log('connectix_sync update: ' . $e->getMessage());
            }
        } else {
            try {
                $st = $pdo->prepare("INSERT INTO product (name_product,code_product,price_product,Volume_constraint,Service_time,Location,agent,data_limit_reset,note,category,hide_panel,one_buy_status,max_users) VALUES (:n,:code,:p,:v,:t,:loc,'f','no_reset',:note,:c,'{}','0',:m)");
                $st->execute([
                    ':n' => $title,
                    ':code' => $code,
                    ':p' => $price,
                    ':v' => $vol,
                    ':t' => $days,
                    ':loc' => $name,
                    ':note' => $planId,
                    ':c' => $category,
                    ':m' => (string) max(1, $devices),
                ]);
                $added++;
            } catch (Throwable $e) {
                error_log('connectix_sync insert: ' . $e->getMessage());
            }
        }
    }

    // enable category display if setting exists
    try {
        $pdo->exec("UPDATE setting SET statuscategory='oncategory' WHERE statuscategory='offcategory' OR statuscategory IS NULL OR statuscategory=''");
    } catch (Throwable $e) {
    }

    return ['added' => $added, 'updated' => $updated, 'total' => count($plans), 'error' => null];
}

/**
 * Format delivery message for user
 */
function connectix_format_message($planTitle, $username, $password, $text_to_copy = '')
{
    $msg = "✅ سرویس کانکتیکس فعال شد\n\n";
    if ($planTitle !== '') {
        $msg .= "📦 پلن: <b>" . htmlspecialchars($planTitle) . "</b>\n";
    }
    $msg .= "👤 نام کاربری: <code>" . htmlspecialchars($username) . "</code>\n";
    $msg .= "🔑 رمز عبور: <code>" . htmlspecialchars($password) . "</code>\n";
    if ($text_to_copy !== '') {
        $msg .= "\n📋 مشخصات:\n<pre>" . htmlspecialchars(str_replace('`', '', $text_to_copy)) . "</pre>";
    }
    $msg .= "\n\nدر اپلیکیشن کانکتیکس با همین نام کاربری و رمز وارد شوید.";
    return $msg;
}

} // guard
