<?php
/**
 * Connectix seller API — mirza_vali Pro
 *
 * Live base (official spelling):
 *   https://seller-api.connectix.vip/externel/v1
 *
 * Auth: Authorization: Bearer <API_TOKEN>   (password_panel)
 *
 * Public seller endpoints (Swagger /profile/api-token):
 *   GET  /clients
 *   GET  /clients/show
 *   POST /clients/store
 *   GET  /clients/get-enabled-plans
 *   POST /clients/add-plan
 *
 * Panel row:
 *   type           = connectix
 *   url_panel      = https://seller-api.connectix.vip/externel/v1
 *   password_panel = API token
 *
 * Product after sync:
 *   note     = plan UUID
 *   category = کانکتیکس
 *   Location = name_panel
 */

if (!function_exists('connectix_request')) {

function connectix_default_base()
{
    return 'https://seller-api.connectix.vip/externel/v1';
}

/**
 * Normalize any URL the admin typed into the live /externel/v1 base.
 * Fixes the old bot bug that appended /external/v1 onto /externel/v1.
 */
function connectix_normalize_base($url)
{
    $base = trim((string) $url);
    $base = rtrim($base, '/');
    if ($base === '' || strcasecmp($base, 'null') === 0) {
        return connectix_default_base();
    }
    $base = preg_replace('#^http://#i', 'https://', $base);

    // strip accidental doubled suffixes
    $base = preg_replace('#/(externel|external)/v\d+(?:/(externel|external)/v\d+)+$#i', '/externel/v1', $base);

    if (preg_match('#/(externel|external)/v\d+$#i', $base)) {
        return preg_replace('#/(externel|external)/v\d+$#i', '/externel/v1', $base);
    }

    $host = strtolower((string) parse_url($base, PHP_URL_HOST));
    if ($host === 'seller-api.connectix.vip' || $host === 'api.connectix.vip' || $host === 'seller.connectix.vip') {
        return connectix_default_base();
    }

    return $base . '/externel/v1';
}

function connectix_get_panel($namepanel)
{
    if (is_array($namepanel)) {
        if (($namepanel['type'] ?? '') !== 'connectix') {
            return null;
        }
        return $namepanel;
    }
    $panel = select('marzban_panel', '*', 'name_panel', $namepanel, 'select');
    if (!is_array($panel) || ($panel['type'] ?? '') !== 'connectix') {
        return null;
    }
    return $panel;
}

function connectix_request($method, $endpoint, $panel, $body = null, $multipart = false)
{
    $base = connectix_normalize_base($panel['url_panel'] ?? '');
    $endpoint = '/' . ltrim((string) $endpoint, '/');
    $url = $base . $endpoint;
    $token = trim((string) ($panel['password_panel'] ?? ''));
    if ($token === '' || strcasecmp($token, 'null') === 0) {
        return ['http_code' => 0, 'error' => 'missing API token', 'body' => null, 'url' => $url];
    }

    $ch = curl_init($url);
    $headers = [
        'Accept: application/json',
        'Authorization: Bearer ' . $token,
    ];
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, strtoupper($method));
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true);

    if ($body !== null) {
        if ($multipart) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        } else {
            $headers[] = 'Content-Type: application/json';
            curl_setopt($ch, CURLOPT_POSTFIELDS, is_string($body) ? $body : json_encode($body, JSON_UNESCAPED_UNICODE));
        }
    }
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    $raw = curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $cerr = curl_error($ch);
    curl_close($ch);

    $decoded = null;
    if (is_string($raw) && $raw !== '') {
        $decoded = json_decode($raw, true);
    }
    $out = [
        'http_code' => $code,
        'body' => $decoded,
        'raw' => is_string($raw) ? mb_substr($raw, 0, 4000) : '',
        'url' => $url,
    ];
    if ($cerr) {
        $out['error'] = $cerr;
    }
    if (is_array($decoded)) {
        if (isset($decoded['message'])) {
            $out['message'] = $decoded['message'];
        }
        foreach ($decoded as $k => $v) {
            if (!isset($out[$k])) {
                $out[$k] = $v;
            }
        }
    }
    return $out;
}

function connectix_http_ok($result)
{
    $c = (int) ($result['http_code'] ?? 0);
    return $c >= 200 && $c < 300 && empty($result['error']);
}

function connectix_pick($arr, $keys, $default = '')
{
    if (!is_array($arr)) {
        return $default;
    }
    foreach ((array) $keys as $k) {
        if (strpos($k, '.') !== false) {
            $cur = $arr;
            $ok = true;
            foreach (explode('.', $k) as $part) {
                if (!is_array($cur) || !isset($cur[$part])) {
                    $ok = false;
                    break;
                }
                $cur = $cur[$part];
            }
            if ($ok && $cur !== '' && $cur !== null && !is_array($cur)) {
                return $cur;
            }
            continue;
        }
        if (isset($arr[$k]) && $arr[$k] !== '' && $arr[$k] !== null && !is_array($arr[$k])) {
            return $arr[$k];
        }
    }
    return $default;
}

function connectix_plan_group($plan)
{
    $group = trim((string) connectix_pick($plan, [
        'group_name',
        'group',
        'group_title',
        'plan_group',
        'groupName',
        'data.group',
        'plan.group',
        'attributes.group',
        'group.title',
        'group.name',
    ], ''));
    if ($group !== '' && strcasecmp($group, 'default') === 0) {
        return 'Super special';
    }
    return $group;
}

/** Shop name from GROUP NAME (default → Super special) + traffic GB */
function connectix_plan_title($plan)
{
    $group = connectix_plan_group($plan);
    $traffic = connectix_pick($plan, ['traffic_amount', 'traffic', 'volume', 'traffic_gb'], '');
    $vol = '';
    if (is_numeric($traffic)) {
        $vol = (string) (0 + $traffic);
    } elseif (is_string($traffic) && preg_match('/(\d+(?:\.\d+)?)/', $traffic, $vm)) {
        $vol = $vm[1];
    }
    if ($group !== '') {
        return $vol !== '' ? ($group . ' ' . $vol . 'G') : $group;
    }
    $title = trim((string) connectix_pick($plan, [
        'title', 'name', 'plan_title', 'planTitle', 'full_title',
        'display_name', 'label', 'data.title', 'plan.title', 'attributes.title',
    ], ''));
    if ($title !== '') {
        return $title;
    }
    return $vol !== '' ? ($vol . 'G') : 'Connectix Plan';
}

function connectix_is_free_test_plan($title, $plan = [])
{
    $blob = mb_strtolower((string) $title);
    if (is_array($plan)) {
        foreach (['title', 'name', 'plan_title', 'full_period_text', 'label'] as $k) {
            if (!empty($plan[$k])) {
                $blob .= ' ' . mb_strtolower((string) $plan[$k]);
            }
        }
    }
    if (preg_match('/\bfree\b|آزمایش|تست رایگان/u', $blob)) {
        return true;
    }
    $days = 0;
    if (is_array($plan)) {
        $days = intval($plan['full_period_days'] ?? $plan['period'] ?? $plan['days'] ?? $plan['Service_time'] ?? 0);
    }
    return $days === 1;
}

/** plan_id used by دکمه اکانت تست */
function connectix_test_plan_id($namepanel)
{
    $panel = connectix_get_panel($namepanel);
    if (!$panel) {
        return '';
    }
    global $pdo;
    try {
        $st = $pdo->prepare("SELECT note FROM product WHERE Location = :loc AND one_buy_status = 'test' AND note IS NOT NULL AND note != '' ORDER BY name_product ASC LIMIT 1");
        $st->execute([':loc' => $panel['name_panel']]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if ($row && !empty($row['note'])) {
            return (string) $row['note'];
        }
    } catch (Throwable $e) {
    }
    $stored = trim((string) ($panel['inboundid'] ?? ''));
    if ($stored !== '' && strcasecmp($stored, 'null') !== 0 && !preg_match('/^[0-9]+$/', $stored) && strlen($stored) >= 8) {
        return $stored;
    }
    return '';
}

function connectix_list_test_products($namepanel = null)
{
    global $pdo;
    $loc = '';
    if ($namepanel) {
        $panel = connectix_get_panel($namepanel);
        if ($panel) {
            $loc = (string) $panel['name_panel'];
        } elseif (is_string($namepanel)) {
            $loc = $namepanel;
        }
    }
    try {
        $sql = "SELECT * FROM product WHERE (
            one_buy_status = 'test'
            OR CAST(Service_time AS UNSIGNED) = 1
            OR name_product LIKE '%free%'
            OR name_product LIKE '%Free%'
            OR category = 'تست'
        )";
        $params = [];
        if ($loc !== '') {
            $sql .= " AND Location = :loc";
            $params[':loc'] = $loc;
        } else {
            $sql .= " AND Location IN (SELECT name_panel FROM marzban_panel WHERE type = 'connectix')";
        }
        $sql .= " ORDER BY name_product ASC";
        $st = $pdo->prepare($sql);
        $st->execute($params);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        return is_array($rows) ? $rows : [];
    } catch (Throwable $e) {
        error_log('connectix_list_test_products: ' . $e->getMessage());
        return [];
    }
}

function connectix_gen_password($len = 8)
{
    $len = max(5, min(8, (int) $len));
    $chars = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789';
    $out = '';
    for ($i = 0; $i < $len; $i++) {
        $out .= $chars[random_int(0, strlen($chars) - 1)];
    }
    return $out;
}

function connectix_parse_credentials($text_to_copy)
{
    $text = str_replace('`', '', (string) $text_to_copy);
    $user = '';
    $pass = '';
    if (preg_match('/username\s*:\s*([^\s\n]+)/iu', $text, $m)) {
        $user = trim($m[1]);
    }
    if (preg_match('/password\s*:\s*([^\s\n]+)/iu', $text, $m)) {
        $pass = trim($m[1]);
    }
    return ['username' => $user, 'password' => $pass, 'raw' => $text_to_copy];
}

/** GET /clients/get-enabled-plans */
function connectix_get_plans($namepanel)
{
    $panel = connectix_get_panel($namepanel);
    if (!$panel) {
        return ['http_code' => 0, 'error' => 'panel not found', 'plans' => []];
    }
    $res = connectix_request('GET', '/clients/get-enabled-plans', $panel);
    $plans = [];
    $body = is_array($res['body'] ?? null) ? $res['body'] : $res;
    if (isset($body['plans']) && is_array($body['plans'])) {
        $plans = $body['plans'];
    } elseif (isset($body['data']) && is_array($body['data'])) {
        $plans = $body['data'];
    } elseif (isset($body[0]) && is_array($body[0])) {
        $plans = $body;
    }
    $res['plans'] = $plans;
    return $res;
}

/** GET /clients */
function connectix_list_clients($namepanel)
{
    $panel = connectix_get_panel($namepanel);
    if (!$panel) {
        return ['http_code' => 0, 'error' => 'panel not found', 'clients' => []];
    }
    $res = connectix_request('GET', '/clients', $panel);
    $clients = [];
    $body = is_array($res['body'] ?? null) ? $res['body'] : [];
    foreach (['clients', 'data', 'users'] as $k) {
        if (isset($body[$k]) && is_array($body[$k])) {
            $clients = $body[$k];
            break;
        }
    }
    if ($clients === [] && isset($body[0]) && is_array($body[0])) {
        $clients = $body;
    }
    $res['clients'] = $clients;
    return $res;
}

/**
 * GET /clients/show
 * Tries query + path variants because Swagger does not show the param name.
 */
function connectix_show_client($namepanel, $usernameOrId)
{
    $panel = connectix_get_panel($namepanel);
    if (!$panel) {
        return ['http_code' => 0, 'error' => 'panel not found', 'client' => null];
    }
    $id = rawurlencode((string) $usernameOrId);
    $tries = [
        '/clients/show?username=' . $id,
        '/clients/show?name=' . $id,
        '/clients/show?id=' . $id,
        '/clients/show/' . $id,
        '/clients/show?client_id=' . $id,
    ];
    $last = null;
    foreach ($tries as $ep) {
        $res = connectix_request('GET', $ep, $panel);
        $last = $res;
        if (!connectix_http_ok($res)) {
            continue;
        }
        $body = is_array($res['body'] ?? null) ? $res['body'] : [];
        $client = $body['client'] ?? $body['data'] ?? $body['user'] ?? $body;
        if (is_array($client) && $client !== []) {
            $res['client'] = $client;
            return $res;
        }
    }
    if (is_array($last)) {
        $last['client'] = null;
    }
    return $last ?: ['http_code' => 0, 'error' => 'show failed', 'client' => null];
}

function connectix_find_client_id($namepanel, $username)
{
    $show = connectix_show_client($namepanel, $username);
    if (connectix_http_ok($show) && is_array($show['client'] ?? null)) {
        $id = connectix_pick($show['client'], ['id', 'client_id', 'uuid', 'user_id']);
        if ($id !== '') {
            return ['id' => (string) $id, 'client' => $show['client'], 'error' => null];
        }
    }
    $list = connectix_list_clients($namepanel);
    if (connectix_http_ok($list)) {
        $uname = strtolower((string) $username);
        foreach ($list['clients'] as $c) {
            if (!is_array($c)) {
                continue;
            }
            $candidates = [
                $c['username'] ?? '',
                $c['name'] ?? '',
                $c['user_name'] ?? '',
                $c['id'] ?? '',
            ];
            foreach ($candidates as $cand) {
                if (strtolower((string) $cand) === $uname) {
                    $id = connectix_pick($c, ['id', 'client_id', 'uuid']);
                    return ['id' => (string) $id, 'client' => $c, 'error' => null];
                }
            }
        }
    }
    return ['id' => '', 'client' => $show['client'] ?? null, 'error' => $show['message'] ?? $list['message'] ?? 'client not found'];
}

/** POST /clients/store  multipart */
function connectix_create_client($namepanel, $plan_id, $password, $extra = [])
{
    $panel = connectix_get_panel($namepanel);
    if (!$panel) {
        return ['http_code' => 0, 'error' => 'panel not found', 'success' => false];
    }
    $form = [
        'password' => (string) $password,
        'plan_id' => (string) $plan_id,
    ];
    foreach (['telegram_id', 'name', 'phone', 'email', 'chat_id'] as $k) {
        if (isset($extra[$k]) && $extra[$k] !== '' && $extra[$k] !== null) {
            $form[$k] = (string) $extra[$k];
        }
    }
    if (isset($extra['enable_plan_after_first_login'])) {
        $form['enable_plan_after_first_login'] = $extra['enable_plan_after_first_login'] ? '1' : '0';
    }
    if (isset($extra['is_child_protection_enabled'])) {
        $form['is_child_protection_enabled'] = $extra['is_child_protection_enabled'] ? '1' : '0';
    }

    $res = connectix_request('POST', '/clients/store', $panel, $form, true);
    $res['success'] = connectix_http_ok($res);
    return $res;
}

/**
 * POST /clients/add-plan
 * Used for both "add plan" and "renew/extend" on Connectix.
 */
function connectix_add_plan($namepanel, $username, $plan_id, $extra = [])
{
    $panel = connectix_get_panel($namepanel);
    if (!$panel) {
        return ['http_code' => 0, 'error' => 'panel not found', 'success' => false];
    }
    $found = connectix_find_client_id($panel, $username);
    $clientId = $found['id'];

    $form = [
        'plan_id' => (string) $plan_id,
        'username' => (string) $username,
        'name' => (string) $username,
    ];
    if ($clientId !== '') {
        $form['client_id'] = $clientId;
        $form['id'] = $clientId;
        $form['user_id'] = $clientId;
    }
    foreach (['password', 'telegram_id', 'phone', 'email'] as $k) {
        if (!empty($extra[$k])) {
            $form[$k] = (string) $extra[$k];
        }
    }

    $res = connectix_request('POST', '/clients/add-plan', $panel, $form, true);
    if (!connectix_http_ok($res)) {
        $json = $form;
        $res2 = connectix_request('POST', '/clients/add-plan', $panel, $json, false);
        if (connectix_http_ok($res2)) {
            $res = $res2;
        }
    }
    $res['success'] = connectix_http_ok($res);
    $res['client_id'] = $clientId;
    return $res;
}

function connectix_extend_client($namepanel, $username, $plan_id, $extra = [])
{
    $panel = connectix_get_panel($namepanel);
    if (!$panel) {
        return ['status' => false, 'msg' => 'panel not found'];
    }
    $res = connectix_add_plan($panel, $username, $plan_id, $extra);
    if (connectix_http_ok($res)) {
        return ['status' => true, 'msg' => 'ok', 'raw' => $res];
    }
    $msg = $res['message'] ?? $res['error'] ?? ('HTTP ' . ($res['http_code'] ?? 0));
    return ['status' => false, 'msg' => $msg, 'raw' => $res];
}

function connectix_data_user($namepanel, $username)
{
    $show = connectix_show_client($namepanel, $username);
    $client = is_array($show['client'] ?? null) ? $show['client'] : [];
    $expire = connectix_pick($client, ['expire', 'expired_at', 'expires_at', 'end_date', 'plan_expired_at'], 0);
    if (is_string($expire) && $expire !== '' && !is_numeric($expire)) {
        $ts = strtotime($expire);
        $expire = $ts ? $ts : 0;
    }
    $limit = connectix_pick($client, ['data_limit', 'traffic', 'traffic_amount', 'volume'], 0);
    $used = connectix_pick($client, ['used_traffic', 'traffic_used', 'used'], 0);
    $status = connectix_pick($client, ['status', 'state', 'is_active'], 'active');
    if ($status === '1' || $status === 1 || $status === true) {
        $status = 'active';
    }
    if ($status === '0' || $status === 0 || $status === false) {
        $status = 'disabled';
    }
    return [
        'status' => $status !== '' ? $status : 'active',
        'username' => $username,
        'data_limit' => is_numeric($limit) ? (int) $limit : 0,
        'expire' => is_numeric($expire) ? (int) $expire : 0,
        'used_traffic' => is_numeric($used) ? (int) $used : 0,
        '_connectix' => true,
        '_cx_client' => $client,
    ];
}

function connectix_sync_products($namepanel)
{
    global $pdo;
    $panel = connectix_get_panel($namepanel);
    if (!$panel) {
        return ['added' => 0, 'updated' => 0, 'total' => 0, 'error' => 'panel not found'];
    }
    $name = $panel['name_panel'];
    $res = connectix_get_plans($panel);
    if (!connectix_http_ok($res)) {
        $detail = $res['message'] ?? $res['error'] ?? ('HTTP ' . ($res['http_code'] ?? 0));
        $url = $res['url'] ?? connectix_normalize_base($panel['url_panel'] ?? '');
        return [
            'added' => 0,
            'updated' => 0,
            'total' => 0,
            'error' => $detail,
            'url' => $url,
        ];
    }
    $plans = $res['plans'] ?? [];
    $added = 0;
    $updated = 0;
    $skipped = 0;
    $category = 'کانکتیکس';
    $testPlanId = '';
    $testDays = 0;
    $testVol = 0;

    foreach ($plans as $plan) {
        if (!is_array($plan)) {
            continue;
        }
        $planId = (string) connectix_pick($plan, ['id', 'plan_id', 'uuid']);
        if ($planId === '') {
            continue;
        }
        $title = connectix_plan_title($plan);
        if (connectix_is_free_test_plan($title, $plan)) {
            if ($testPlanId === '') {
                $testPlanId = $planId;
                $testDays = intval(connectix_pick($plan, ['full_period_days', 'period', 'days'], 0));
                $trafficT = connectix_pick($plan, ['traffic_amount', 'traffic', 'volume'], '');
                if (is_numeric($trafficT)) {
                    $testVol = intval($trafficT);
                } elseif (is_string($trafficT) && preg_match('/(\d+)/', $trafficT, $vm)) {
                    $testVol = intval($vm[1]);
                }
            }
            $price = '0';
            $days = (string) intval(connectix_pick($plan, ['full_period_days', 'period', 'days'], 0));
            $traffic = connectix_pick($plan, ['traffic_amount', 'traffic', 'volume'], '');
            $vol = '0';
            if (is_numeric($traffic)) {
                $vol = (string) intval($traffic);
            } elseif (is_string($traffic) && preg_match('/(\d+)/', $traffic, $vm)) {
                $vol = $vm[1];
            }
            $devices = intval(connectix_pick($plan, ['count_of_devices', 'devices', 'max_clients'], 1));
            $code = substr(md5('cx|test|' . $name . '|' . $planId), 0, 10);
            try {
                $st = $pdo->prepare("SELECT id FROM product WHERE note = :note AND Location = :loc LIMIT 1");
                $st->execute([':note' => $planId, ':loc' => $name]);
                $ex = $st->fetch(PDO::FETCH_ASSOC);
                if ($ex) {
                    $st = $pdo->prepare("UPDATE product SET name_product=:n, price_product='0', Volume_constraint=:v, Service_time=:t, category='تست', one_buy_status='test', max_users=:m WHERE id=:id");
                    $st->execute([':n' => $title, ':v' => $vol, ':t' => $days, ':m' => (string) max(1, $devices), ':id' => $ex['id']]);
                } else {
                    $st = $pdo->prepare("INSERT INTO product (name_product,code_product,price_product,Volume_constraint,Service_time,Location,agent,data_limit_reset,note,category,hide_panel,one_buy_status,max_users) VALUES (:n,:code,'0',:v,:t,:loc,'f','no_reset',:note,'تست','{}','test',:m)");
                    $st->execute([':n' => $title, ':code' => $code, ':v' => $vol, ':t' => $days, ':loc' => $name, ':note' => $planId, ':m' => (string) max(1, $devices)]);
                }
            } catch (Throwable $e) {
                error_log('connectix_sync test product: ' . $e->getMessage());
            }
            $skipped++;
            continue;
        }
        $price = (string) connectix_pick($plan, ['sell_price', 'price', 'amount'], '0');
        $days = (string) intval(connectix_pick($plan, ['full_period_days', 'period', 'days'], 0));
        $traffic = connectix_pick($plan, ['traffic_amount', 'traffic', 'volume'], '');
        $vol = 0;
        if (is_numeric($traffic)) {
            $vol = (string) intval($traffic);
        } elseif (is_string($traffic) && preg_match('/(\d+)/', $traffic, $vm)) {
            $vol = $vm[1];
        }
        $devices = intval(connectix_pick($plan, ['count_of_devices', 'devices', 'max_clients'], 1));
        $code = substr(md5('cx|' . $name . '|' . $planId), 0, 10);

        $existing = null;
        try {
            $st = $pdo->prepare("SELECT id, code_product FROM product WHERE note = :note AND Location = :loc LIMIT 1");
            $st->execute([':note' => $planId, ':loc' => $name]);
            $existing = $st->fetch(PDO::FETCH_ASSOC);
        } catch (Throwable $e) {
        }

        if ($existing) {
            try {
                $st = $pdo->prepare("UPDATE product SET name_product=:n, price_product=:p, Volume_constraint=:v, Service_time=:t, category=:c, max_users=:m WHERE id=:id");
                $st->execute([
                    ':n' => $title,
                    ':p' => $price,
                    ':v' => $vol,
                    ':t' => $days,
                    ':c' => $category,
                    ':m' => (string) $devices,
                    ':id' => $existing['id'],
                ]);
                $updated++;
            } catch (Throwable $e) {
                error_log('connectix_sync update: ' . $e->getMessage());
            }
        } else {
            try {
                $st = $pdo->prepare("INSERT INTO product (name_product,code_product,price_product,Volume_constraint,Service_time,Location,agent,data_limit_reset,note,category,hide_panel,one_buy_status,max_users) VALUES (:n,:code,:p,:v,:t,:loc,'f','no_reset',:note,:c,'{}','0',:m)");
                $st->execute([
                    ':n' => $title,
                    ':code' => $code,
                    ':p' => $price,
                    ':v' => $vol,
                    ':t' => $days,
                    ':loc' => $name,
                    ':note' => $planId,
                    ':c' => $category,
                    ':m' => (string) max(1, $devices),
                ]);
                $added++;
            } catch (Throwable $e) {
                error_log('connectix_sync insert: ' . $e->getMessage());
            }
        }
    }

    try {
        $pdo->exec("UPDATE setting SET statuscategory='oncategory' WHERE statuscategory='offcategory' OR statuscategory IS NULL OR statuscategory=''");
    } catch (Throwable $e) {
    }

    if ($testPlanId !== '') {
        try {
            $st = $pdo->prepare("UPDATE marzban_panel SET inboundid = :pid, TestAccount = 'ONTestAccount' WHERE name_panel = :n AND type = 'connectix'");
            $st->execute([':pid' => $testPlanId, ':n' => $name]);
            if ($testDays > 0) {
                $hours = max(1, $testDays * 24);
                $st = $pdo->prepare("UPDATE marzban_panel SET time_usertest = :h WHERE name_panel = :n AND type = 'connectix'");
                $st->execute([':h' => (string) $hours, ':n' => $name]);
            }
            if ($testVol > 0) {
                $st = $pdo->prepare("UPDATE marzban_panel SET val_usertest = :v WHERE name_panel = :n AND type = 'connectix'");
                $st->execute([':v' => (string) $testVol, ':n' => $name]);
            }
        } catch (Throwable $e) {
            error_log('connectix_sync test panel: ' . $e->getMessage());
        }
    }

    return ['added' => $added, 'updated' => $updated, 'skipped' => $skipped, 'total' => count($plans), 'error' => null, 'test_plan' => $testPlanId];
}

function connectix_format_message($planTitle, $username, $password, $text_to_copy = '')
{
    $msg = "✅ سرویس کانکتیکس فعال شد\n\n";
    if ($planTitle !== '') {
        $msg .= "📦 پلن: <b>" . htmlspecialchars($planTitle) . "</b>\n";
    }
    $msg .= "👤 نام کاربری: <code>" . htmlspecialchars($username) . "</code>\n";
    $msg .= "🔑 رمز عبور: <code>" . htmlspecialchars($password) . "</code>\n";
    if ($text_to_copy !== '') {
        $msg .= "\n📋 مشخصات:\n<pre>" . htmlspecialchars(str_replace('`', '', $text_to_copy)) . "</pre>";
    }
    $msg .= "\n\nدر اپلیکیشن کانکتیکس با همین نام کاربری و رمز وارد شوید.";
    return $msg;
}

function connectix_plan_id_from_product($product)
{
    if (!is_array($product)) {
        return '';
    }
    foreach (['note', 'inbounds'] as $k) {
        if (!empty($product[$k])) {
            return trim((string) $product[$k]);
        }
    }
    return '';
}

} // guard
