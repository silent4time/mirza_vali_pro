# mirza_vali Pro — Changelog

## v4.0.9 (2026-08-28)

### رفع ارتباط با سرور لایسنس
- افزایش timeout و غیرفعال‌سازی سخت‌گیرانه SSL روی کلاینت لایسنس (علت رایج پیام «سرور در دسترس نیست»)
- لاگ خطای curl برای عیب‌یابی

## v4.0.8 (2026-08-28)

### رفع قطعی ماژول لایسنس
- `license_client.php` همیشه در Install و Update کپی می‌شود
- کلید واردشده در نصب از `config.php` به دیتابیس (`PaySetting`) همگام می‌شود
- اگر کلید فقط در config باشد، منوی ربات آن را می‌بیند
- آدرس API پیش‌فرض obfuscated؛ نیازی به وارد کردن URL در نصب نیست

## v4.0.7 (2026-08-28)

### لایسنس داخل ربات + پنهان‌سازی API
- منوی **🔑 لایسنس ربات** در پنل مدیریت (فقط administrator)
- ثبت / ویرایش کلید لایسنس از داخل ربات (ذخیره در PaySetting + config.php)
- نمایش وضعیت: دامنه، کلید ماسک‌شده، انقضا، روز باقی‌مانده، فروش فعال/متوقف
- آدرس API سرور لایسنس به‌صورت obfuscated داخل کلاینت (نه متن ساده در config)
- `$LICENSE_API_URL` خالی = استفاده از endpoint داخلی رمزشده

## v4.0.6 (2026-08-28)

### رفع ازکارافتادگی ربات (HTTP 500)
- حذف تعریف تکراری `eylan_delete_user` / `eylan_toggle_user` / `eylan_reset_traffic` در `Eylan.php`
- توابع کمکی اضافی با `function_exists` محافظت شدند
- علت: Cannot redeclare function eylan_delete_user()

## v4.0.5 (2026-08-28)

### رفع پایداری
- اصلاح placeholder تکراری PDO در `KeyboardCategoryGlobal` / `KeyboardPanelsForCategory`
- مقاوم‌سازی ویرایش محصول وقتی پنل در session نیست

## v4.0.4 (2026-08-28)

### هم‌راستا با کلاسیک v2.0.7
- دکمه‌های بازگشت: منوی قبل / منوی مدیریت / منوی اصلی کاربر
- خرید با دسته فعال: دسته → پنل → محصول (`KeyboardCategoryGlobal` / `catbuy_`)
- step برای منوهای ادمین (فروشگاه، محصولات، دسته، تنظیمات، کانال)
- ویرایش محصول: `product_edit_flow` و بازگشت یک‌مرحله‌ای
- پاک‌سازی دامنه/IP واقعی از مستندات؛ فقط مثال (`bot.example.com`، `license.example.com`)

## v4.0.4 (2026-08-27)
- Fix: license check no longer runs on every webhook (was causing bot timeout / appear offline)
- License HTTP timeout reduced (3s connect / 6s total)
- License still enforced only on sell/buy flows; `/license` still works for admin


## v4.0.3 (2026-08-27)

### لایسنس کلاینت (اتصال به سرور لایسنس)
- فایل `license_client.php`: بررسی دوره‌ای لایسنس با API
- قفل فقط روی دامنه (`$domainhosts`)
- انقضا → فقط توقف فروش (ربات قطع نمی‌شود)
- هشدار ~۷ روز قبل و پیام انقضا به ادمین تلگرام/بله
- مهلت (grace) ۹۶ ساعته اگر سرور لایسنس در دسترس نباشد
- کش محلی در `storage/license_cache.json`
- دستور ادمین: `/license`
- هنگام نصب: پرسش License key و License API URL
- متغیرهای `config.php`: `$LICENSE_ENABLED`, `$LICENSE_KEY`, `$LICENSE_API_URL`

### نوت و مستندات
- README و CHANGELOG مخصوص Pro (نه نسخه کلاسیک)
- نسخه در VERSION و پیام aboutBot: 4.0.3

---

## v4.0.2
- مسیر نصب پیش‌فرض: `/home/mirza_vali_pro`
- STATE: `/etc/mirza_vali_pro`
- برندینگ Pro

## v4.0.1
- اصلاحات نصب و برندینگ اولیه Pro

## v4.0.0
- شروع خط Pro (جدا از mirza_vali کلاسیک ≤ v2.0.1 و خط v3)
- پشتیبانی Connectix + چندنصب موازی
- امکانات سفارشی بله‌پی و پنل ایلان از خط قبلی

---

> تاریخچه نسخه کلاسیک (mirza_vali بدون Pro) در ریپوی جدا / بسته‌های v1.x و v2.x نگهداری می‌شود.