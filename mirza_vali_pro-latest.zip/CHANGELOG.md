## 1.8.61
- Compact tariff list
- Version strings synced (VERSION, note, README, aboutBot)

## 1.8.34
- README fully synced: version, /home/mirza_vali paths, update commands
- All release files coordinated (VERSION, manage, README, installer)

## 1.8.32
- Default install path restored: `/home/mirza_vali`
- Cleanup leftover `/var/www/mirza_vali` after install/update

# mirza_vali — Changelog

## v1.8.7
- Payment flow restored to stable v1.8.3 behavior (removed goto / Processing_value_one that broke receipt)
- Single min/max message for cart range
- Keep id_user unpaid check + receipt fallback lookup
- Keep backupbot.php fix from v1.8.6
- Keep QR sendMessageService improvements from v1.8.3

# mirza_vali — Changelog

## v1.8.2
- Update downloads mirza_vali-latest.zip from GitHub (no need for patch/ folder in repo root)


## v1.8.0 (2026-08-06)

### Management menu (aligned with official Mirza style)
1. Install mirza_vali
2. Update mirza_vali
3. Remove mirza_vali
4. Reset (webhooks / tunnel / domain)
5. Renew SSL certificate
6. Help & Parameters
7. Status
0. Exit

- CLI: `install|update|remove|reset|renew|status|help`
- Symlink: `/usr/local/bin/mirza_vali` after install
- No Free→Pro migrate (not applicable to this fork)


## v1.7.0 (2026-08-06)

### Install reliability
- Install **fails** if `table.php` does not create the `setting` table (no silent skip)
- Installs `phpX.Y-mysql` for **all** PHP versions on the server (CLI vs Apache mismatch fix)
- DNS check uses `dig -4` (IPv6 timeout workaround)
- `select()` initializes `$result` on query failure (fewer PHP warnings)

### Web helper
- Updated `generate-installer.html` for GitHub one-liner + Apache/SSL notes


## v1.6.0 (2026-08-04)

### Automatic SSL (Let's Encrypt)
- On install with own domain: Apache :80 vhost + certbot --apache automatically
- Reset menu option 4: Set domain + auto SSL + webhooks
- Waits for DNS resolve (up to 90s) before requesting certificate


## v1.5.0 (2026-08-04)

### Apache instead of Nginx
- Install uses **Apache2 + mod_php** (same stack as other bots on the server)
- Does **not** install or enable Nginx; if Nginx is present it is stopped/disabled to free port 80
- mirza_vali listens on dedicated port **8091** so other Apache virtual hosts on :80 are not disturbed
- Cloudflare tunnel points to `http://localhost:8091`
- Other Apache sites are not disabled


## v1.4.0 (2026-08-02)

### Zip-based GitHub install
- Upload a single file `mirza_vali-latest.zip` to the repo root (no need to upload patch/ folder via web)
- `install.sh` downloads the zip, extracts it to `/opt/mirza_vali-src`, then opens the menu
- One-liner unchanged: `curl -fsSL .../install.sh | sudo bash`


## v1.3.3 (2026-08-02)

### Fix incomplete GitHub repo / double-clone crash
- install.sh verifies patch/ exists after clone and shows a clear error if missing
- manage.sh no longer deletes /opt/mirza_vali-src while running from it
- If already inside the source tree, skips a second git clone
